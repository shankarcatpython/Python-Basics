
INSERT INTO customer (customer_id, name, email, phone, address) VALUES (1, 'Teresa Hunter', 'harveyerika@example.net', '(396)966-6552', '832 Jennifer Lane Suite 500\nCareyton, TX 75792');
INSERT INTO invoice (invoice_id, customer_id, invoice_date, total_amount) VALUES (1, 1, '2024-03-14', 1997.0);
INSERT INTO invoice (invoice_id, customer_id, invoice_date, total_amount) VALUES (2, 1, '2024-01-03', 3204.0);
INSERT INTO invoice (invoice_id, customer_id, invoice_date, total_amount) VALUES (3, 1, '2024-03-10', 6989.0);
