
package com.example.controller;

import com.example.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/exportCustomers")
    public String exportCustomersToJson() {
        try {
            customerService.exportCustomersToJson("customers_invoices.json");
            return "Customer data has been exported to customers_invoices.json";
        } catch (IOException e) {
            return "Error: " + e.getMessage();
        }
    }
}
