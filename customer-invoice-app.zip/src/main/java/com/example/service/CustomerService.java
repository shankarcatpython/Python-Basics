
package com.example.service;

import com.example.entity.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ObjectMapper objectMapper;

    // Fetch all customers with their invoices using Criteria API
    public List<Customer> getAllCustomersWithCriteria() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Customer> cq = cb.createQuery(Customer.class);
        Root<Customer> customerRoot = cq.from(Customer.class);
        customerRoot.fetch("invoices");
        cq.select(customerRoot).distinct(true);
        return entityManager.createQuery(cq).getResultList();
    }

    // Write customer and invoice data to a JSON file
    public void exportCustomersToJson(String filePath) throws IOException {
        List<Customer> customers = getAllCustomersWithCriteria();
        objectMapper.writeValue(new File(filePath), customers);
    }
}
